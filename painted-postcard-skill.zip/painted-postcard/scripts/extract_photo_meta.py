#!/usr/bin/env python3
"""从照片中提取 EXIF 拍摄日期和 GPS 地点信息，用于明信片落款。

用法:
    python3 scripts/extract_photo_meta.py <照片路径>

输出:
    JSON，包含 date (YYYY.MM.DD 或 null)、datetime_original、gps（若有）。
    无 EXIF 或读取失败时对应字段为 null，不报错退出（退出码仍为 0），
    由调用方决定回退为询问用户。
"""

import json
import sys


def extract(path: str) -> dict:
    result = {"date": None, "datetime_original": None, "gps": None}
    try:
        from PIL import Image
        from PIL.ExifTags import TAGS, GPSTAGS
    except ImportError:
        return result

    try:
        with Image.open(path) as img:
            exif = img.getexif()
            if not exif:
                return result

            # 拍摄时间：优先 DateTimeOriginal (36867)，其次 DateTime (306)
            dt = None
            for tag_id in (36867, 36868, 306):
                try:
                    value = exif.get_ifd(0x8769).get(tag_id) if tag_id in (36867, 36868) else exif.get(tag_id)
                except Exception:
                    value = None
                if value:
                    dt = str(value).strip()
                    break
            if dt:
                result["datetime_original"] = dt
                # EXIF 格式 "YYYY:MM:DD HH:MM:SS" -> "YYYY.MM.DD"
                date_part = dt.split(" ")[0].replace(":", ".")
                if len(date_part) == 10:
                    result["date"] = date_part

            # GPS 信息（仅原样输出坐标，地点名称需调用方自行判断或询问用户）
            try:
                gps_ifd = exif.get_ifd(0x8825)
                if gps_ifd:
                    gps = {GPSTAGS.get(k, k): v for k, v in gps_ifd.items()}
                    if gps:
                        result["gps"] = {k: str(v) for k, v in gps.items()}
            except Exception:
                pass
    except Exception:
        pass
    return result


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print(json.dumps({"error": "usage: extract_photo_meta.py <photo_path>"}))
        sys.exit(1)
    print(json.dumps(extract(sys.argv[1]), ensure_ascii=False, indent=2))
